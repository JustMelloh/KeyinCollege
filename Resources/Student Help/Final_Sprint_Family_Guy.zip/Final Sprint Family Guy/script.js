fetch("characters.json")
  .then((response) => response.json())
  .then((familyguyCharacters) => {
    const firstYear =
      familyguyCharacters.firstYearEpisodeAppearance.getFullYear();
    const lastYear =
      familyguyCharacters.lastYearEpisodeAppearance.getFullYear();
    let numYear = lastYear - firstYear;
    let html = "";
    familyguyCharacters.forEach((familyguy) => {
      const firstYear = familyguy.firstYearEpisodeAppearance.getFullYear();
      const lastYear = familyguy.lastYearEpisodeAppearance.getFullYear();
      let numYear = lastYear - firstYear;
      html += `
        <ul>
        <li>${familyguy.name}</li>
        <li>Home: ${familyguy.home}</li>
        <li>Family-
        <li>Partner(s): ${familyguy.partners.join(", ")}</li>
        <li>Children: ${familyguy.children.join(", ")}</li>
        <li>First appeared on: ${familyguy.firstEpisodeAppearance}.</li>
        <li>First appeared in: ${familyguy.firstYearEpisodeAppearance}</li>
        <li>Last appeared in: ${familyguy.lastYearEpisodeAppearance}</li>
        ${numYear}
        </ul>
      `;
    });
  });
document.body.innerHTML = html;
