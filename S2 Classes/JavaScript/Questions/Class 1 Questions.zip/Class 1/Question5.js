var byte1 =  100
var byte2 = 104
var byte3 = 4
var byte4 = 2

var ipAdd = byte1 + "." + byte2 + "." + byte3 + "." + byte4

console.log(ipAdd)