var isNotKeyin;
if (domainName === "keyincollege.ca") {
    isNotKeyin = false;
} else {
    isNotKeyin = true;
}
