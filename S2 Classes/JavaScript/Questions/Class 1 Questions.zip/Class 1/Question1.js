var label = "keyincollege";
var tld = "ca";
var domainName = label + "." + tld;

console.log(domainName)