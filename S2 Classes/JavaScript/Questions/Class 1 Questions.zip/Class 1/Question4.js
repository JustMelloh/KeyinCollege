var byte1 =  100
var byte2 = 104
var byte3 = 4
var byte4 = 2

