var isKeyin;
if (domainName === "keyincollege.ca") {
    isKeyin = true;
} else {
    isKeyin = false;
}
